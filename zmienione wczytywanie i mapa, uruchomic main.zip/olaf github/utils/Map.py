import os
import folium
import json
import pycountry
from typing import List, Optional
from utils.reader_excel import Figura


class Map:
    def __init__(self):
        self.output_path = os.path.join("resources", "map.html")
        self.geojson_path = os.path.join("resources", "europe.geojson")

    def generate_europe_choropleth_map(self, data_list: Optional[List[Figura]] = None) -> str:
        if not os.path.exists(self.geojson_path):
            print(f"Plik GeoJSON nie istnieje: {self.geojson_path}")
            return ""

        # Tworzymy mapę
        m = folium.Map(location=[54.5, 15], zoom_start=4, tiles=None)

        # Ładujemy dane geojson
        with open(self.geojson_path, encoding='utf-8') as f:
            geojson_data = json.load(f)

        # Przetwarzamy dane: country_name -> (latest_year, latest_value)
        country_data = {}
        if data_list:
            for fig in data_list:
                name = fig.country.strip()
                if name not in country_data or fig.year > country_data[name][0]:
                    country_data[name] = (fig.year, fig.value)

        # Konwersja nazw krajów na ISO_A3
        
        name_to_iso = {}
        for country in pycountry.countries:
            name_to_iso[country.name] = country.alpha_3
            if hasattr(country, 'official_name'):
                name_to_iso[country.official_name] = country.alpha_3

        # Mapujemy dane na ISO_A3
        iso_data = {}
        for country_name, (year, value) in country_data.items():
            iso_code = name_to_iso.get(country_name)
            if iso_code:
                iso_data[iso_code] = {'value': value, 'year': year}
                print(f"[OK] {iso_code} ({country_name}) -> {year}: {value}")
            else:
                print(f"Nie znaleziono ISO kodu dla: {country_name}")

        # Dodajemy popupy do każdego kraju
        print("=== ISO_A3 w geojson ===")
        geojson_isos = set()
        for feature in geojson_data["features"]:
            iso = feature["properties"].get("ISO_A3")
            geojson_isos.add(iso)
        print(sorted(geojson_isos))

        print("=== ISO_A3 z danych ===")
        print(sorted(iso_data.keys()))


        
        for feature in geojson_data["features"]:
            iso = feature["properties"].get("ISO3")
            country_name = feature["properties"].get("NAME")
            value_info = iso_data.get(iso)

            if value_info:
                popup_text = f"{country_name}<br>Year: {value_info['year']}<br>Value: {value_info['value']}"
                fill_color = "#228B22"
            else:
                popup_text = f"{country_name}<br>No data"
                fill_color = "#999999"

            folium.GeoJson(
                feature,
                style_function=lambda x, fc=fill_color: {
                    "fillColor": fc,
                    "color": "black",
                    "weight": 1,
                    "fillOpacity": 0.6
                },
                tooltip=folium.Tooltip(popup_text)
            ).add_to(m)

        # Zapisujemy mapę do pliku HTML
        m.save(self.output_path)
        print(f"Mapa zapisana w: {self.output_path}")
        return self.output_path
