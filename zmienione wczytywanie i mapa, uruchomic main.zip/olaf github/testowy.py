from PyQt5.QtWidgets import QApplication, QMainWindow
import sys

class TestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Test Window")

if __name__ == "__main__":
    app = QApplication([])
    win = TestWindow()
    win.show()
    sys.exit(app.exec_())

