class Voivodeships:
    def __init__(self):
        self.__voivodeships = [
            "dolnośląskie", "kujawsko-pomorskie", "lubelskie", "lubuskie",
            "łódzkie", "małopolskie", "mazowieckie", "opolskie",
            "podkarpackie", "podlaskie", "pomorskie", "śląskie",
            "świętokrzyskie", "warmińsko-mazurskie", "wielkopolskie", "zachodniopomorskie"
        ]

    def get_voivodeships_list(self):
        return self.__voivodeships
